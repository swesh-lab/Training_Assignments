package com.example.androidJavaToKot

import android.app.Activity
import java.util.*

class ExerciseActivityMapper {
    private var exerciseClassMap: HashMap<String, Class<out Activity?>>? = null
    private fun defineExerciseMappings() {
        exerciseClassMap = HashMap()
        //  Chapter 1 To 10 Exercises
        exerciseClassMap!!["chap1ex1"] = BasicTextViewActivity::class.java
        exerciseClassMap!!["chap2ex1"] = LinearLayoutDemoActivity::class.java
        exerciseClassMap!!["chap3ex1"] = LayoutGravityActivity::class.java
        exerciseClassMap!!["chap3ex2"] = BasicViewActivity::class.java
        exerciseClassMap!!["chap3ex3"] = ViewAttributesActivity::class.java
        exerciseClassMap!!["chap3ex4"] = SimpleListViewActivity::class.java
        exerciseClassMap!!["chap4ex1"] = BasicClickHandlersActivity::class.java
        exerciseClassMap!!["chap4ex2"] = ListViewClickActivity::class.java
        exerciseClassMap!!["chap5ex1"] = ExplicitIntentActivity::class.java
        exerciseClassMap!!["chap5ex2"] = ImplicitIntentActivity::class.java
        exerciseClassMap!!["chap5ex3"] = IntentWithResultActivity::class.java
        exerciseClassMap!!["chap5ex4"] = ActionBarMenuActivity::class.java
        exerciseClassMap!!["chap6ex1"] = BasicImageDownloadActivity::class.java
        exerciseClassMap!!["chap6ex2"] = AsyncTaskPerformActivity::class.java
        exerciseClassMap!!["chap7ex1"] = ToastFormInputActivity::class.java
        exerciseClassMap!!["chap7ex2"] = SpinnerToastActivity::class.java
        exerciseClassMap!!["chap7ex3"] = TimePickerActivity::class.java
        exerciseClassMap!!["chap7ex4"] = GridViewActivity::class.java
        exerciseClassMap!!["chap8ex1"] = PersistSettingsActivity::class.java
        exerciseClassMap!!["chap9ex1"] = ContactListActivity::class.java
        exerciseClassMap!!["chap10ex1"] = PublishingActivity::class.java
    }

    companion object {
        private var singleton: ExerciseActivityMapper? = null
            private get() {
                if (field == null) {
                    field = ExerciseActivityMapper()
                }
                return field
            }

        fun getExerciseClass(exerciseId: String): Class<out Activity?> {
            return singleton!!.exerciseClassMap!![exerciseId]!!
        }
    }

    init {
        defineExerciseMappings()
    }
}
