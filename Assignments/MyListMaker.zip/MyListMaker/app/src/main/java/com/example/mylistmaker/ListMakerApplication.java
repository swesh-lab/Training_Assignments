package com.example.mylistmaker;

import android.app.Application;

public class ListMakerApplication extends Application {
}
